import deckyPlugin from "@decky/rollup";

export default deckyPlugin({
  watch: {
    clearScreen: false
  }
});
